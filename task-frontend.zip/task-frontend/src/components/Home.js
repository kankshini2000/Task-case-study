import React from "react";
import Navbar from "./Navbar";
function Home() {
  return (
    <div>
      <h1>This is FORM- Management Systems!!!</h1>
    </div>
  );
}

export default Home;
