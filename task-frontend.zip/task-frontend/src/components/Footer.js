import React from "react";
// import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer-container">
      <h2>Copyright: @Form - Systems 2023</h2>
    </footer>
  );
};

export default Footer;
