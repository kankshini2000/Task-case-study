import React from "react";

function Thankyou() {
  return (
    <div className="card-container">
      <div className="card">
        <h1>Microsoft Form</h1>
        <p>Thank you for submitting the form!</p>
        {/* <p><a href="/report">Go to Report</a></p> */}
      </div>
    </div>
  );
}

export default Thankyou;
